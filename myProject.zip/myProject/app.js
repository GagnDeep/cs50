/*global d3*/

d3.queue()
    .defer(d3.json, '//unpkg.com/world-atlas@1.1.4/world/50m.json')
    .defer(d3.csv, './data/all_data.csv', row=>{
        return {
            country : row.Country,
            continent : row.Continent,
            countryCode : row['Country Code'],
            emissions : row['Emissions'],
            emissionsPerCapita : row['Emissions Per Capita'],
            region : row.Region,
            year : row.year
        }
    })
    .await((error, mapData, data)=>{
        
        if(error) throw error;
        console.log(data)
        // let geoData = topojson.feature(mapData, )
    })